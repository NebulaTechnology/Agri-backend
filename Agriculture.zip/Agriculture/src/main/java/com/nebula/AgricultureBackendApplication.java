package com.nebula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgricultureBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgricultureBackendApplication.class, args);
	}

}
