package com.nebula.entity;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
public class Bill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long billNo;

    @Column(name = "customer_id")
    private Long custId;

    @ElementCollection
    @CollectionTable(name = "bill_item_ids", joinColumns = @JoinColumn(name = "bill_no"))
    @Column(name = "item_id")
    private List<Long> itemId;

    @ElementCollection
    @CollectionTable(name = "bill_batch_nums", joinColumns = @JoinColumn(name = "bill_no"))
    @Column(name = "batch_num")
    private List<String> batchNum;

    @ElementCollection
    @CollectionTable(name = "bill_prod_expiry", joinColumns = @JoinColumn(name = "bill_no"))
    @Column(name = "prod_expiry")
    private List<String> prodExpiry;

    @ElementCollection
    @CollectionTable(name = "bill_product_quantity", joinColumns = @JoinColumn(name = "bill_no"))
    @Column(name = "product_quantity")
    private List<Integer> productQuantity;

    @ElementCollection
    @CollectionTable(name = "bill_product_cgst", joinColumns = @JoinColumn(name = "bill_no"))
    @Column(name = "product_cgst")
    private List<Double> productCGST;

    @ElementCollection
    @CollectionTable(name = "bill_product_agst", joinColumns = @JoinColumn(name = "bill_no"))
    @Column(name = "product_agst")
    private List<Double> productAGST;

    @ElementCollection
    @CollectionTable(name = "bill_product_igst", joinColumns = @JoinColumn(name = "bill_no"))
    @Column(name = "product_igst")
    private List<Double> productIGST;

    @ElementCollection
    @CollectionTable(name = "bill_product_hsn", joinColumns = @JoinColumn(name = "bill_no"))
    @Column(name = "product_hsn")
    private List<String> productHSN;

    @ElementCollection
    @CollectionTable(name = "bill_product_company", joinColumns = @JoinColumn(name = "bill_no"))
    @Column(name = "product_company")
    private List<String> productCompany;

    private Double csgt;
    private Double sgst;
    private Double igst;
    private Double totalAmmount;
    private Double paidAmmount;
    private Double remainingAmmount;
}
